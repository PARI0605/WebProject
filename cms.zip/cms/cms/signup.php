<?php
// Enable error reporting
error_reporting(E_ALL);
ini_set('display_errors', 1);

include 'db.php';

if (isset($_SERVER["REQUEST_METHOD"]) && $_SERVER["REQUEST_METHOD"] == "post") {
    $name = $_POST['name'];
    $username = $_POST['username'];
    $email = $_POST['email'];
    $password = $_POST['password'];
    $confirm_password = $_POST['confirm-password'];

    // Check if passwords match
    if ($password !== $confirm_password) {
        die("Passwords do not match.");
    }

    // Debugging - Print received values
    echo "Name: $name, Username: $username, Email: $email, Password: $password, Confirm Password: $confirm_password<br>";

    // Prepare a statement to avoid SQL injection
    $stmt = $conn->prepare("INSERT INTO signup (name, username, email, password, confirm_password) VALUES (?, ?, ?, ?, ?)");
    if (!$stmt) {
        die("Prepare statement failed: " . $conn->error);
    }
    $stmt->bind_param("sssss", $name, $username, $email, $password, $confirm_password);

    // Execute the statement and check for errors
    if ($stmt->execute()) {
        echo "New record created successfully";
    } else {
        echo "Error: " . $stmt->error;
    }

    $stmt->close();
    $conn->close();
} else {
    echo "No POST request detected.";
}
?>
