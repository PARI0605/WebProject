const header = document.querySelector("header");

window.addEventListener("scroll", function () {
    header.classList.toggle("sticky", window.scrollY > 60)
});
let menu = document.querySelector('#menu-icon');
let navbar = document.querySelector('.navbar')
menu.onclick = () => {
    menu.classList.toggle('bx-x');
    navbar.classList.toggle('open');
};
window.botpress.init({
    "botId": "d3aea06d-0f04-4701-bec3-b457caf79902",
    "configuration": {
      "website": {},
      "email": {},
      "phone": {},
      "termsOfService": {},
      "privacyPolicy": {},
      "color": "#3B82F6",
      "variant": "solid",
      "themeMode": "light",
      "fontFamily": "inter",
      "radius": 1
    },
    "clientId": "0e772c62-e321-46b5-a9fb-a88c5104e067"
  });

